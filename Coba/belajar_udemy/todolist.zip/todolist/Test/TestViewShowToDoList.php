<?php

require_once '../View/viewShowToDoList.php';
require_once '../BusinessLogic/addToDoList.php';

addToDoList("Auro");
addToDoList("Daniel");
addToDoList("Ersa");
addToDoList("Silalahi");
addToDoList("Prorgrammer");

viewShowToDoList();